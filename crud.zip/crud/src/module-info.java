/**
 * 
 */
/**
 * 
 */
module crud {
	requires java.sql;
}